# Backend Code for PCA + ANN Face Recognition (Flask)


from flask import Flask, request, jsonify
import os
import zipfile
import numpy as np
import cv2
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from tensorflow.keras import layers, models
from tensorflow.keras.models import load_model as keras_load_model
import joblib

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
EXTRACTED_FOLDER = 'extracted_images'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(EXTRACTED_FOLDER, exist_ok=True)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '' or not file.filename.endswith('.zip'):
        return jsonify({'error': 'Invalid file format'}), 400

    zip_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(zip_path)
    extract_images(zip_path)

    X, y, label_dict = load_images_from_folder(EXTRACTED_FOLDER)
    X_flat = X.reshape((X.shape[0], -1))

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_flat)

    pca = PCA(n_components=150)
    X_pca = pca.fit_transform(X_scaled)

    model = train_ann(X_pca, y, len(label_dict))

    joblib.dump(scaler, 'scaler.pkl')
    joblib.dump(pca, 'pca.pkl')
    joblib.dump(label_dict, 'label_dict.pkl')
    model.save('face_recognition_model.h5')

    return jsonify({
        'message': 'Training completed successfully!',
        'num_identities': len(label_dict)
    }), 200

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    model = keras_load_model('face_recognition_model.h5')
    pca = joblib.load('pca.pkl')
    scaler = joblib.load('scaler.pkl')
    label_dict = joblib.load('label_dict.pkl')
    label_inv_map = {v: k for k, v in label_dict.items()}

    img = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, (100, 100))
    img = img.flatten().reshape(1, -1)

    img_scaled = scaler.transform(img)
    img_pca = pca.transform(img_scaled)

    pred = model.predict(img_pca)
    predicted_class = np.argmax(pred)
    confidence = float(np.max(pred)) * 100

    return jsonify({
        'predicted_label': label_inv_map[predicted_class],
        'confidence': round(confidence, 2)
    })

def extract_images(zip_path):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(EXTRACTED_FOLDER)

def load_images_from_folder(folder):
    images, labels, label_dict = [], [], {}
    label_count = 0
    for person in os.listdir(folder):
        person_path = os.path.join(folder, person)
        if os.path.isdir(person_path):
            if person not in label_dict:
                label_dict[person] = label_count
                label_count += 1
            for filename in os.listdir(person_path):
                img_path = os.path.join(person_path, filename)
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                if img is not None:
                    img = cv2.resize(img, (100, 100))
                    images.append(img)
                    labels.append(label_dict[person])
    return np.array(images), np.array(labels), label_dict

def train_ann(X, y, num_classes):
    model = models.Sequential()
    model.add(layers.Dense(128, activation='relu', input_shape=(X.shape[1],)))
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(num_classes, activation='softmax'))
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    model.fit(X, y, epochs=50, batch_size=32, verbose=1)
    return model

if __name__ == '__main__':
    app.run(debug=True)